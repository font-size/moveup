'use strict';
module.exports = {
  authInfo: {
    key: 'Tsld2o4elg',
  },
};
