'use strict';

const BaseService = require('./base');

class TestService extends BaseService {}

module.exports = TestService;
