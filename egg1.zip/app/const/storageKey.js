'use strict';

module.exports = {
  EGG_CONFIG: 'egg_config',
  ELECTRON_IPC: 'electron_ipc',
  TEST_DATA: 'test_data'
};